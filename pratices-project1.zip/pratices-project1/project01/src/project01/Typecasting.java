package project01;

public class Typecasting {

	public static void main(String[] args) {  
	//impilict type
		int a=1;
		float b=a;
		System.out.println("output of b" + b);
		
		//expilict type
		float c=2.20f;
		int d=(int)c;
		System.out.println("output of d" + d);

	}

}
